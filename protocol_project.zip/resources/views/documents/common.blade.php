<x-app-layout>

    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Κοινή Προβολή Εγγράφων
        </h2>
    </x-slot>

    <div class="py-6">

        @forelse($incomingGroups as $incoming)

            <div class="card p-4 mb-5">
                <h2>Εισερχόμενο Α/Α: {{ $incoming->aa ?? '' }}</h2>

                <table border="1" width="100%" cellpadding="5" style="margin-top:10px;">
                    <thead>
                    <tr>
                        <th>Α/Α</th>
                        <th>Ημερομηνία Παραλαβής</th>
                        <th>Αριθμός Εισερχομένου</th>
                        <th>Τόπος</th>
                        <th>Αρχή</th>
                        <th>Χρονολογία</th>
                        <th>Περίληψη</th>
                        <th>Φάκελος</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{{ $incoming->aa ?? '' }}</td>
                            <td>{{ $incoming->received_date ?? '' }}</td>
                            <td>{{ $incoming->incoming_number ?? '' }}</td>
                            <td>{{ $incoming->place ?? '' }}</td>
                            <td>{{ $incoming->authority ?? '' }}</td>
                            <td>{{ $incoming->year ?? '' }}</td>
                            <td>{{ $incoming->summary ?? '' }}</td>
                            <td>{{ $incoming->folder ?? '' }}</td>
                        </tr>
                    </tbody>
                </table>

                <h2 style="margin-top:25px;">Σχετικές Απαντήσεις (Εξερχόμενα)</h2>

                <table border="1" width="100%" cellpadding="5" style="margin-top:10px;">
                    <thead>
                    <tr>
                        <th>Α/Α</th>
                        <th>Αρχή</th>
                        <th>Περίληψη</th>
                        <th>Χρονολογία</th>
                        <th>Σχετικοί Αριθμοί</th>
                        <th>Φάκελος</th>
                        <th>Παρατηρήσεις</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($incoming->outgoingReplies as $out)
                        <tr>
                            <td>{{ $out->aa ?? '' }}</td>
                            <td>{{ $out->target ?? '' }}</td>
                            <td>{{ $out->summary ?? '' }}</td>
                            <td>{{ $out->year ?? '' }}</td>
                            <td>{{ $out->related ?? '' }}</td>
                            <td>{{ $out->folder ?? '' }}</td>
                            <td>{{ $out->notes ?? '' }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7">Δεν υπάρχουν εξερχόμενα (απαντήσεις)</td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>

            </div>

        @empty
            <div class="card p-4">
                Δεν υπάρχουν κοινές εγγραφές.
            </div>
        @endforelse

    </div>

</x-app-layout>
