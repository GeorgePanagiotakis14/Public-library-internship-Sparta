<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Νέος Χρήστης
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="card" style="max-width: 700px;">
        <?php if($errors->any()): ?>
            <div style="margin-bottom: 15px; color: #b91c1c;">
                <ul style="margin:0; padding-left:18px;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.users.store')); ?>">
            <?php echo csrf_field(); ?>

            <div style="margin-bottom:10px;">
                <label>Όνομα</label><br>
                <input name="name" value="<?php echo e(old('name')); ?>" style="width:100%;">
            </div>

            <div style="margin-bottom:10px;">
                <label>Email</label><br>
                <input name="email" value="<?php echo e(old('email')); ?>" style="width:100%;">
            </div>

            <div style="margin-bottom:10px;">
                <label>Password</label><br>
                <input type="password" name="password" style="width:100%;">
            </div>

            <div style="margin-bottom:10px;">
                <label>Confirm Password</label><br>
                <input type="password" name="password_confirmation" style="width:100%;">
            </div>

            <div style="margin-bottom:15px;">
                <label>
                    <input type="checkbox" name="is_admin" value="1" <?php echo e(old('is_admin') ? 'checked' : ''); ?>>
                    Είναι Admin (Superuser)
                </label>
            </div>

            <button type="submit">Δημιουργία</button>
            <a href="<?php echo e(route('admin.users.index')); ?>" style="margin-left:10px;">Άκυρο</a>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel2\laravel-app\resources\views/admin/users/create.blade.php ENDPATH**/ ?>