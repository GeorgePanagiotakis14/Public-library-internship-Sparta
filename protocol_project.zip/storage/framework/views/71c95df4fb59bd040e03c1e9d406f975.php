<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>Εισερχόμενα - Εξερχόμενα</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #1f2937;
            color: #fff;
            position: fixed;
            padding: 20px;
        }
        .sidebar h2 {
            margin-bottom: 30px;
            font-size: 18px;
        }
        .sidebar a {
            display: block;
            color: #cbd5e1;
            text-decoration: none;
            margin-bottom: 15px;
        }
        .sidebar a.active {
         color: #ffffff;
         font-weight: 500;
         background: rgba(255, 255, 255, 0.12);
         border-radius: 6px;

         /* αγκαλιάζει */
         padding: 6px 10px;

         /* ΑΥΤΟ ΚΑΝΕΙ ΤΟ MAGIC */
         line-height: 1.4;
         display: inline-block;
         }

        .sidebar a:hover {
            color: #f2f3f3;
        }
        .content {
            margin-left: 250px;
            padding: 0px;
        }
        .card {
            background: #fff;
            padding: 20px;
            border-radius: 6px;
        }
        /* FIX: Επαναφέρει τα πλαίσια στους πίνακες μέσα σε card */
        .card table {
            width: 100%;
            border-collapse: collapse;
        }

        .card table th,
        .card table td {
           border: 1px solid #030303; /* ουδέτερο γκρι */
           padding: 6px;
           vertical-align: top;
        }

    </style>
</head>
<body>

<div class="sidebar">
    <h2>Μενού</h2>

    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
    Αρχική
    </a>

    <a href="<?php echo e(route('documents.create')); ?>" class="<?php echo e(request()->routeIs('documents.create') ? 'active' : ''); ?>">
    Συμπλήρωση Εισερχομένου / Εξερχομένου
    </a>


    <hr>

    <a href="<?php echo e(route('incoming.index')); ?>" class="<?php echo e(request()->routeIs('incoming.*') ? 'active' : ''); ?>">
    Εμφάνιση Εισερχομένων
    </a>
    
    <a href="<?php echo e(route('outgoing.index')); ?>" class="<?php echo e(request()->routeIs('outgoing.*') ? 'active' : ''); ?>">
    Εμφάνιση Εξερχομένων
    </a>

    <a href="<?php echo e(route('documents.common')); ?>" class="<?php echo e(request()->routeIs('documents.common') ? 'active' : ''); ?>">
    Κοινά Εισερχόμενα - Εξερχόμενα
    </a>
    
    <?php if(auth()->user()?->is_admin): ?>
    <a href="<?php echo e(route('admin.audit.index')); ?>"
       class="<?php echo e(request()->routeIs('admin.audit.*') ? 'active' : ''); ?>">
        Audit Log
    </a>
    <?php endif; ?>


    <?php if(auth()->user()?->is_admin): ?>
    <a href="<?php echo e(route('admin.users.index')); ?>"
       class="<?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>">
        Διαχείριση Χρηστών
    </a>
    <?php endif; ?>

    <hr>
    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" style="
            background:none;
            border:none;
            color:#cbd5e1;
            padding:0;
            cursor:pointer;
            margin-top:20px;
        ">
            Αποσύνδεση
        </button>
    </form>
</div>

<div class="content">

    <?php if(isset($header)): ?>
        <div style="margin-bottom: 25px;">
            <?php echo e($header); ?>

        </div>
    <?php endif; ?>

    <?php echo e($slot); ?>


</div>

</body>
</html>
<?php /**PATH C:\Laravel2\laravel-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>