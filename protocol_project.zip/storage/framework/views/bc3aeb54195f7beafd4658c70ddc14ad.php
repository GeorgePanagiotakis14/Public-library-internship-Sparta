<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Κοινή Προβολή Εγγράφων
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">

        <?php $__empty_1 = true; $__currentLoopData = $incomingGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incoming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="card p-4 mb-5">
                <h2>Εισερχόμενο Α/Α: <?php echo e($incoming->aa ?? ''); ?></h2>

                <table border="1" width="100%" cellpadding="5" style="margin-top:10px;">
                    <thead>
                    <tr>
                        <th>Α/Α</th>
                        <th>Ημερομηνία Παραλαβής</th>
                        <th>Αριθμός Εισερχομένου</th>
                        <th>Τόπος</th>
                        <th>Αρχή</th>
                        <th>Χρονολογία</th>
                        <th>Περίληψη</th>
                        <th>Φάκελος</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($incoming->aa ?? ''); ?></td>
                            <td><?php echo e($incoming->received_date ?? ''); ?></td>
                            <td><?php echo e($incoming->incoming_number ?? ''); ?></td>
                            <td><?php echo e($incoming->place ?? ''); ?></td>
                            <td><?php echo e($incoming->authority ?? ''); ?></td>
                            <td><?php echo e($incoming->year ?? ''); ?></td>
                            <td><?php echo e($incoming->summary ?? ''); ?></td>
                            <td><?php echo e($incoming->folder ?? ''); ?></td>
                        </tr>
                    </tbody>
                </table>

                <h2 style="margin-top:25px;">Σχετικές Απαντήσεις (Εξερχόμενα)</h2>

                <table border="1" width="100%" cellpadding="5" style="margin-top:10px;">
                    <thead>
                    <tr>
                        <th>Α/Α</th>
                        <th>Αρχή</th>
                        <th>Περίληψη</th>
                        <th>Χρονολογία</th>
                        <th>Σχετικοί Αριθμοί</th>
                        <th>Φάκελος</th>
                        <th>Παρατηρήσεις</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_2 = true; $__currentLoopData = $incoming->outgoingReplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $out): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <tr>
                            <td><?php echo e($out->aa ?? ''); ?></td>
                            <td><?php echo e($out->target ?? ''); ?></td>
                            <td><?php echo e($out->summary ?? ''); ?></td>
                            <td><?php echo e($out->year ?? ''); ?></td>
                            <td><?php echo e($out->related ?? ''); ?></td>
                            <td><?php echo e($out->folder ?? ''); ?></td>
                            <td><?php echo e($out->notes ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <tr>
                            <td colspan="7">Δεν υπάρχουν εξερχόμενα (απαντήσεις)</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card p-4">
                Δεν υπάρχουν κοινές εγγραφές.
            </div>
        <?php endif; ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel2\laravel-app\resources\views/documents/common.blade.php ENDPATH**/ ?>