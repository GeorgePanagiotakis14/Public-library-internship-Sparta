<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Εισερχόμενα Έγγραφα
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="card">
        <h2>Εισερχόμενα Έγγραφα</h2>

        <table border="1" width="100%" cellpadding="5">
            <thead>
            <tr>
                <th>Α/Α</th>
                <th>Ημερομηνία Παραλαβής</th>
                <th>Αριθμός Πρωτοκόλλου</th>
                <th>Τόπος που εκδόθηκε</th>
                <th>Αρχή που το εξέδωσε</th>
                <th>Χρονολογία εγγράφου</th>
                <th>Περίληψη</th>
                <th>Φάκελος Αρχείου</th>
            </tr>
            </thead>

            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($doc->aa); ?></td>
                    <td><?php echo e($doc->incoming_date); ?></td>
                    <td><?php echo e($doc->protocol_number); ?></td>
                    <td><?php echo e($doc->sender); ?></td>
                    <td><?php echo e($doc->subject); ?></td>
                    <td><?php echo e($doc->document_date); ?></td>
                    <td><?php echo e($doc->summary); ?></td>
                    <td><?php echo e($doc->comments); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" align="center">Δεν υπάρχουν εγγραφές</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>

        <?php echo e($documents->links()); ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel2\laravel-app\resources\views/incoming/index.blade.php ENDPATH**/ ?>