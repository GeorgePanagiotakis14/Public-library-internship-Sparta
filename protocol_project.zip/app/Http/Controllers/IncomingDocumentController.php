<?php

namespace App\Http\Controllers;

use App\Models\IncomingDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IncomingDocumentController extends Controller
{
    public function index()
    {
        $documents = IncomingDocument::orderBy('aa', 'asc')->paginate(10);
        return view('incoming.index', compact('documents'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'protocol_number'   => 'nullable|string',
            'incoming_protocol' => 'nullable|string',
            'incoming_date'     => 'nullable|date',
            'subject'           => 'nullable|string',
            'sender'            => 'nullable|string',
            'document_date'     => 'nullable|date',
            'summary'           => 'nullable|string',
            'comments'          => 'nullable|string',
        ]);

        $document = DB::transaction(function () use ($validated) {
            $nextAa = (int) (IncomingDocument::lockForUpdate()->max('aa') ?? 0) + 1;

            return IncomingDocument::create([
                ...$validated,
                'aa' => $nextAa,
                'protocol_number' => (string) $nextAa, // κρατάμε και το protocol_number ίδιο για να ταιριάζει με ό,τι έχεις ήδη στη φόρμα/queries
            ]);
        });

        audit_log('incoming', 'create', $document->id);

        return redirect()->back()->with('success', 'Το εισερχόμενο καταχωρήθηκε επιτυχώς.');
    }

    public function edit($id)
    {
        $document = IncomingDocument::findOrFail($id);
        return view('incoming.edit', compact('document'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'protocol_number'   => 'nullable|string',
            'incoming_protocol' => 'nullable|string',
            'incoming_date'     => 'nullable|date',
            'subject'           => 'nullable|string',
            'sender'            => 'nullable|string',
            'document_date'     => 'nullable|date',
            'summary'           => 'nullable|string',
            'comments'          => 'nullable|string',
        ]);

        IncomingDocument::findOrFail($id)->update($validated);

        audit_log('incoming', 'update', $id);

        return redirect()->route('incoming.index')->with('success', 'Το εισερχόμενο ενημερώθηκε.');
    }

    public function destroy($id)
    {
        audit_log('incoming', 'delete', $id);

        IncomingDocument::findOrFail($id)->delete();

        return redirect()->back()->with('success', 'Το εισερχόμενο διαγράφηκε.');
    }
}
