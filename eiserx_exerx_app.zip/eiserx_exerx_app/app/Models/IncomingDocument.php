<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IncomingDocument extends Model
{
    use HasFactory;

    protected $table = 'incoming_documents';

    protected $fillable = [
        'protocol_number',
        'incoming_protocol',
        'incoming_date',
        'subject',
        'sender',
        'document_date',
        'summary',
        'comments',
    ];
}
