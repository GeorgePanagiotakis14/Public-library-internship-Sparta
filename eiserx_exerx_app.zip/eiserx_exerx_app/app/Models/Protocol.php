<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Protocol extends Model
{
    protected $fillable = [
    'incoming_date',
    'incoming_sender',
    'incoming_subject',
    'incoming_description',
    'incoming_file',
    'outgoing_receiver',
    'outgoing_description',
    'outgoing_date'
    ];

}
