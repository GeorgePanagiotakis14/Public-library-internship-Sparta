<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OutgoingDocument extends Model
{
    use HasFactory;

    protected $table = 'outgoing_documents';

    protected $fillable = [
        'protocol_number',
        'incoming_protocol',
        'incoming_date',
        'subject',
        'sender',
        'document_date',
        'incoming_document_number',
        'summary',
        'comments',
    ];
}
