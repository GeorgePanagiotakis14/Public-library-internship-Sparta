<?php

namespace App\Http\Controllers;

use App\Models\IncomingDocument;
use Illuminate\Http\Request;

class IncomingDocumentController extends Controller
{
    public function index()
    {
    $documents = IncomingDocument::orderBy('incoming_date', 'desc')->paginate(10);
    return view('incoming.index', compact('documents'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'protocol_number' => 'nullable|string',
            'incoming_protocol' => 'nullable|string',
            'incoming_date' => 'nullable|date',
            'subject' => 'nullable|string',
            'sender' => 'nullable|string',
            'document_date' => 'nullable|date',
            'summary' => 'nullable|string',
            'comments' => 'nullable|string',
        ]);

        IncomingDocument::create($validated);

        return redirect()->back()->with('success', 'Το εισερχόμενο καταχωρήθηκε επιτυχώς.');
    }
    public function edit($id)
    {
    $document = IncomingDocument::findOrFail($id);
    return view('incoming.edit', compact('document'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'protocol_number' => 'nullable|string',
            'incoming_protocol' => 'nullable|string',
            'incoming_date' => 'nullable|date',
            'subject' => 'nullable|string',
            'sender' => 'nullable|string',
            'document_date' => 'nullable|date',
            'summary' => 'nullable|string',
            'comments' => 'nullable|string',
            ]);

     IncomingDocument::findOrFail($id)->update($validated);

     return redirect()->route('incoming.index')->with('success', 'Το εισερχόμενο ενημερώθηκε.');
     }

     public function destroy($id)
     {
      IncomingDocument::findOrFail($id)->delete();
      return redirect()->back()->with('success', 'Το εισερχόμενο διαγράφηκε.');
     }
}

