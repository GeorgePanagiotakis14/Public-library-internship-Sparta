

<?php $__env->startSection('content'); ?>
<div class="card">
    <h1>Σύστημα Πρωτοκόλλου</h1>
    <p>Διαχείριση Εισερχομένων και Εξερχομένων Εγγράφων.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\eiserx_exerx_app\resources\views/dashboard.blade.php ENDPATH**/ ?>