<h1>Μενού αρχικής σελίδας</h1>

<ul>
    <li><a href="/incoming/create">Νέο εισερχόμενο</a></li>
    <li><a href="/outgoing/create">Νέο εξερχόμενο</a></li>
    <li><a href="/incoming">Φάκελος εισερχομένων</a></li>
    <li><a href="/outgoing">Φάκελος εξερχομένων</a></li>
</ul>

<?php if(session('success')): ?>
    <p style="color: green"><?php echo e(session('success')); ?></p>
<?php endif; ?>
<?php /**PATH C:\eiserx_exerx_app\resources\views/menu.blade.php ENDPATH**/ ?>