

<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Εξερχόμενα Έγγραφα</h2>

    <?php if(session('success')): ?>
        <div style="background:#d1fae5;padding:10px;margin-bottom:15px;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table border="1" width="100%" cellpadding="5">
        <thead>
        <tr>
            <th>Α/Α</th>
            <th>Πρωτόκολλο</th>
            <th>Ημ/νία</th>
            <th>Θέμα</th>
            <th>Αποστολέας</th>
            <th>Αρ. Εισερχομένου</th>
            <th>Ενέργειες</th>
        </tr>
        </thead>

        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($doc->protocol_number); ?></td>
                <td><?php echo e($doc->incoming_protocol); ?></td>
                <td><?php echo e($doc->incoming_date); ?></td>
                <td><?php echo e($doc->subject); ?></td>
                <td><?php echo e($doc->sender); ?></td>
                <td><?php echo e($doc->incoming_document_number); ?></td>
                <td>
                    <a href="<?php echo e(route('outgoing.edit', $doc->id)); ?>">
                        Επεξεργασία
                    </a>

                    |

                    <form action="<?php echo e(route('outgoing.destroy', $doc->id)); ?>"
                          method="POST"
                          style="display:inline"
                          onsubmit="return confirm('Είστε σίγουρος ότι θέλετε διαγραφή;')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Διαγραφή</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" align="center">Δεν υπάρχουν εγγραφές</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <div style="margin-top:15px;">
        <?php echo e($documents->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\eiserx_exerx_app\resources\views/outgoing/index.blade.php ENDPATH**/ ?>