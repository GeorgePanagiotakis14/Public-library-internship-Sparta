

<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Κοινή Προβολή Εισερχομένων – Εξερχομένων</h2>

    <table border="1" width="100%" cellpadding="5">
        <thead>
        <tr>
            <th>Τύπος</th>
            <th>Α/Α</th>
            <th>Πρωτόκολλο</th>
            <th>Ημ/νία</th>
            <th>Θέμα</th>
            <th>Αποστολέας</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($doc->type); ?></td>
                <td><?php echo e($doc->protocol_number); ?></td>
                <td><?php echo e($doc->incoming_protocol); ?></td>
                <td><?php echo e($doc->incoming_date); ?></td>
                <td><?php echo e($doc->subject); ?></td>
                <td><?php echo e($doc->sender); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($documents->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\eiserx_exerx_app\resources\views/documents/common.blade.php ENDPATH**/ ?>