<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>Εισερχόμενα - Εξερχόμενα</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #1f2937;
            color: #fff;
            position: fixed;
            padding: 20px;
        }
        .sidebar h2 {
            margin-bottom: 30px;
            font-size: 18px;
        }
        .sidebar a {
            display: block;
            color: #cbd5e1;
            text-decoration: none;
            margin-bottom: 15px;
        }
        .sidebar a:hover {
            color: #fff;
        }
        .content {
            margin-left: 250px;
            padding: 30px;
        }
        .card {
            background: #fff;
            padding: 20px;
            border-radius: 6px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>Μενού</h2>

    <a href="<?php echo e(route('dashboard')); ?>">Αρχική</a>

    <a href="<?php echo e(route('incoming.index')); ?>">Εμφάνιση Εισερχομένων</a>
    <a href="<?php echo e(route('outgoing.index')); ?>">Εμφάνιση Εξερχομένων</a>

    <hr>

    <a href="<?php echo e(route('documents.create')); ?>">Συμπλήρωση Εισερχομένου / Εξερχομένου</a>
    <a href="<?php echo e(route('documents.common')); ?>">Κοινά Εισερχόμενα - Εξερχόμενα</a>

</div>

<div class="content">
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH C:\eiserx_exerx_app\resources\views/layouts/app.blade.php ENDPATH**/ ?>