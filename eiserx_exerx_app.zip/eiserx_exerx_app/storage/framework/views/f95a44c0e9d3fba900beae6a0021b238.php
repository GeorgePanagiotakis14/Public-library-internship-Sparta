<h2>Φάκελος εξερχομένων</h2>

<ul>
<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="<?php echo e(asset('storage/' . $file)); ?>" target="_blank">
            <?php echo e(basename($file)); ?>

        </a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<a href="/">Πίσω στο μενού</a>
<?php /**PATH C:\eiserx_exerx_app\resources\views/outgoing/list.blade.php ENDPATH**/ ?>