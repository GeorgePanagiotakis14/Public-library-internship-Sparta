<h2>Νέο εισερχόμενο</h2>

<form method="POST" action="/incoming/store" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="file" required>
    <button type="submit">Αποθήκευση</button>
</form>

<a href="/">Πίσω στο μενού</a>
<?php /**PATH C:\eiserx_exerx_app\resources\views/incoming/create.blade.php ENDPATH**/ ?>