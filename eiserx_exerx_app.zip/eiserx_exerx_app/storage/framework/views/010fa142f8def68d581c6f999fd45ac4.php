

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
    <div style="background:#d1fae5;padding:10px;margin-bottom:20px;">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="card">
    <h2>Συμπλήρωση Εισερχομένου</h2>

    <form method="POST" action="<?php echo e(route('incoming.store')); ?>">
        <?php echo csrf_field(); ?>

        <input type="text" name="protocol_number" placeholder="Α/Α"><br><br>
        <input type="text" name="incoming_protocol" placeholder="Αριθμός Πρωτοκόλλου"><br><br>
        <input type="date" name="incoming_date"><br><br>
        <input type="text" name="subject" placeholder="Θέμα"><br><br>
        <input type="text" name="sender" placeholder="Αρχή Αποστολής"><br><br>
        <input type="date" name="document_date"><br><br>

        <textarea name="summary" placeholder="Περιγραφή"></textarea><br><br>
        <textarea name="comments" placeholder="Παρατηρήσεις"></textarea><br><br>

        <button type="submit">Υποβολή Εισερχομένου</button>
    </form>
</div>

<hr style="border:2px solid blue;margin:40px 0;">

<div class="card">
    <h2>Συμπλήρωση Εξερχομένου</h2>

    <form method="POST" action="<?php echo e(route('outgoing.store')); ?>">
        <?php echo csrf_field(); ?>

        <input type="text" name="protocol_number" placeholder="Α/Α"><br><br>
        <input type="text" name="incoming_protocol" placeholder="Αριθμός Πρωτοκόλλου"><br><br>
        <input type="date" name="incoming_date"><br><br>
        <input type="text" name="subject" placeholder="Θέμα"><br><br>
        <input type="text" name="sender" placeholder="Αρχή Αποστολής"><br><br>
        <input type="date" name="document_date"><br><br>

        <input type="text" name="incoming_document_number" placeholder="Αριθμός Εισερχομένου Εγγράφου"><br><br>

        <textarea name="summary" placeholder="Περιγραφή"></textarea><br><br>
        <textarea name="comments" placeholder="Παρατηρήσεις"></textarea><br><br>

        <button type="submit">Υποβολή Εξερχομένου</button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\eiserx_exerx_app\resources\views/documents/create.blade.php ENDPATH**/ ?>