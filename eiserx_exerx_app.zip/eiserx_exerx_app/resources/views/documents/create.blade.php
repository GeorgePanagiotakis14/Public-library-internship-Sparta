@extends('layouts.app')

@section('content')

@if(session('success'))
    <div style="background:#d1fae5;padding:10px;margin-bottom:20px;">
        {{ session('success') }}
    </div>
@endif

<div class="card">
    <h2>Συμπλήρωση Εισερχομένου</h2>

    <form method="POST" action="{{ route('incoming.store') }}">
        @csrf

        <input type="text" name="protocol_number" placeholder="Α/Α"><br><br>
        <input type="text" name="incoming_protocol" placeholder="Αριθμός Πρωτοκόλλου"><br><br>
        <input type="date" name="incoming_date"><br><br>
        <input type="text" name="subject" placeholder="Θέμα"><br><br>
        <input type="text" name="sender" placeholder="Αρχή Αποστολής"><br><br>
        <input type="date" name="document_date"><br><br>

        <textarea name="summary" placeholder="Περιγραφή"></textarea><br><br>
        <textarea name="comments" placeholder="Παρατηρήσεις"></textarea><br><br>

        <button type="submit">Υποβολή Εισερχομένου</button>
    </form>
</div>

<hr style="border:2px solid blue;margin:40px 0;">

<div class="card">
    <h2>Συμπλήρωση Εξερχομένου</h2>

    <form method="POST" action="{{ route('outgoing.store') }}">
        @csrf

        <input type="text" name="protocol_number" placeholder="Α/Α"><br><br>
        <input type="text" name="incoming_protocol" placeholder="Αριθμός Πρωτοκόλλου"><br><br>
        <input type="date" name="incoming_date"><br><br>
        <input type="text" name="subject" placeholder="Θέμα"><br><br>
        <input type="text" name="sender" placeholder="Αρχή Αποστολής"><br><br>
        <input type="date" name="document_date"><br><br>

        <input type="text" name="incoming_document_number" placeholder="Αριθμός Εισερχομένου Εγγράφου"><br><br>

        <textarea name="summary" placeholder="Περιγραφή"></textarea><br><br>
        <textarea name="comments" placeholder="Παρατηρήσεις"></textarea><br><br>

        <button type="submit">Υποβολή Εξερχομένου</button>
    </form>
</div>

@endsection
