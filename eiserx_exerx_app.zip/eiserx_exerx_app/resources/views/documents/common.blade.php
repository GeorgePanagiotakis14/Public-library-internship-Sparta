@extends('layouts.app')

@section('content')
<div class="card">
    <h2>Κοινή Προβολή Εισερχομένων – Εξερχομένων</h2>

    <table border="1" width="100%" cellpadding="5">
        <thead>
        <tr>
            <th>Τύπος</th>
            <th>Α/Α</th>
            <th>Πρωτόκολλο</th>
            <th>Ημ/νία</th>
            <th>Θέμα</th>
            <th>Αποστολέας</th>
        </tr>
        </thead>
        <tbody>
        @foreach($documents as $doc)
            <tr>
                <td>{{ $doc->type }}</td>
                <td>{{ $doc->protocol_number }}</td>
                <td>{{ $doc->incoming_protocol }}</td>
                <td>{{ $doc->incoming_date }}</td>
                <td>{{ $doc->subject }}</td>
                <td>{{ $doc->sender }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    {{ $documents->links() }}
</div>
@endsection
