@extends('layouts.app')

@section('content')
<div class="card">
    <h1>Σύστημα Πρωτοκόλλου</h1>
    <p>Διαχείριση Εισερχομένων και Εξερχομένων Εγγράφων.</p>
</div>
@endsection
