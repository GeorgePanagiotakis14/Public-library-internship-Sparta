@extends('layouts.app')

@section('content')
<div class="card">
    <h2>Εισερχόμενα Έγγραφα</h2>

    @if(session('success'))
        <div style="background:#d1fae5;padding:10px;margin-bottom:15px;">
            {{ session('success') }}
        </div>
    @endif

    <table border="1" width="100%" cellpadding="5">
        <thead>
        <tr>
            <th>Α/Α</th>
            <th>Πρωτόκολλο</th>
            <th>Ημ/νία</th>
            <th>Θέμα</th>
            <th>Αποστολέας</th>
            <th>Ενέργειες</th>
        </tr>
        </thead>

        <tbody>
        @forelse($documents as $doc)
            <tr>
                <td>{{ $doc->protocol_number }}</td>
                <td>{{ $doc->incoming_protocol }}</td>
                <td>{{ $doc->incoming_date }}</td>
                <td>{{ $doc->subject }}</td>
                <td>{{ $doc->sender }}</td>
                <td>
                    <a href="{{ route('incoming.edit', $doc->id) }}">
                        Επεξεργασία
                    </a>

                    |

                    <form action="{{ route('incoming.destroy', $doc->id) }}"
                          method="POST"
                          style="display:inline"
                          onsubmit="return confirm('Είστε σίγουρος ότι θέλετε διαγραφή;')">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Διαγραφή</button>
                    </form>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="6" align="center">Δεν υπάρχουν εγγραφές</td>
            </tr>
        @endforelse
        </tbody>
    </table>

    <div style="margin-top:15px;">
        {{ $documents->links() }}
    </div>
</div>
@endsection
